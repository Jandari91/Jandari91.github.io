﻿using Command;
using Datas;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace CopyTest
{
    public class MainViewModel : PropertyChangedHelper
    {
        public ICommand CopyCommand { get; set; }
        public ICommand PasteCommand { get; set; }

        private ObservableCollection<ColorData> _colors;
        public ObservableCollection<ColorData> Colors
        {
            get { return _colors; }
            set { SetField(ref _colors, value, "ItemsSource"); }
        }

        private ColorData _selectedColor;
        public ColorData SelectedColor
        {
            get { return _selectedColor; }
            set { SetField(ref _selectedColor, value, "SelectedItem"); }
        }

        public MainViewModel()
        {
            CopyCommand = new DelegateCommand(_copyCommandAction);
            PasteCommand = new DelegateCommand(_pasteCommandAction);
            Colors = new ObservableCollection<ColorData>();

            _initColors();
        }

        private void _initColors()
        {
            Colors.Add(new ColorData { BackgroundColor = new SolidColorBrush(System.Windows.Media.Colors.Black), ColorText = "Black" });
            Colors.Add(new ColorData { BackgroundColor = new SolidColorBrush(System.Windows.Media.Colors.Red), ColorText = "Red" });
            Colors.Add(new ColorData { BackgroundColor = new SolidColorBrush(System.Windows.Media.Colors.Blue), ColorText = "Blue" });
            Colors.Add(new ColorData { BackgroundColor = new SolidColorBrush(System.Windows.Media.Colors.Green), ColorText = "Green" });
            Colors.Add(new ColorData { BackgroundColor = new SolidColorBrush(System.Windows.Media.Colors.Orange), ColorText = "Orange" });
            Colors.Add(new ColorData { BackgroundColor = new SolidColorBrush(System.Windows.Media.Colors.Gray), ColorText = "Gray" });
        }

        private void _copyCommandAction()
        {
            Clipboard.Clear();
            var dataObject = new DataObject();
            dataObject.SetData("SelectedColor", SelectedColor, true);
            Clipboard.SetDataObject(dataObject, true);
        }

        private void _pasteCommandAction()
        {
            IDataObject dataObject = Clipboard.GetDataObject();

            if (dataObject.GetDataPresent("SelectedColor"))
            {
                var color = dataObject.GetData("SelectedColor", true) as ColorData;

                Colors.Add(color);
            }
        }
    }
}
