﻿using System;
using System.Runtime.Serialization;

namespace Datas
{
    [DataContract]
    [Serializable]
    public class ColorData
    {
        [NonSerialized]
        private System.Windows.Media.BrushConverter _colorConverter = new System.Windows.Media.BrushConverter();

        [DataMember(Name = "ColorString")]
        private string _colorString;
        public string ColorString
        {
            get { return _colorString; }
            set
            {
                _colorString = value;
                _backgroundColor = (System.Windows.Media.Brush)_colorConverter.ConvertFrom(value);
            }
        }

        [DataMember(Name = "ColorText")]
        private string _colorText;
        public string ColorText
        {
            get { return _colorText; }
            set { _colorText = value;}
        }

        [NonSerialized]
        private System.Windows.Media.Brush _backgroundColor = System.Windows.Media.Brushes.Yellow;
        public System.Windows.Media.Brush BackgroundColor
        {
            get { return _backgroundColor; }
            set
            {
                _backgroundColor = value;
                _colorString = _colorConverter.ConvertToString(value);
            }
        }

        [OnDeserialized]
        private void SetValuesOnDeserialized(StreamingContext context)
        {
            _colorConverter = new System.Windows.Media.BrushConverter();
            _backgroundColor = (System.Windows.Media.Brush)_colorConverter.ConvertFrom(ColorString);
        }
    }
}
