﻿using ItemRemove.Command;
using ItemRemove.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace ItemRemove
{
    public class MainViewModel : PropertyChangedHelper
    {
        private int _itemIndex = 0;

        private string _inputText;
        public string InputText
        {
            get { return _inputText; }
            set { SetField(ref _inputText, value, "ItemsSource"); }
        }

        private ObservableCollection<Item> _items;
        public ObservableCollection<Item> Items
        {
            get { return _items; }
            set { SetField(ref _items, value, "ItemsSource"); }
        }

        private Item _selectedItem;
        public Item SelectedItem
        {
            get { return _selectedItem; }
            set { SetField(ref _selectedItem, value, "ItemsSource"); }
        }

        public ICommand RemoveCommand { get; set; }
        public ICommand InputCommand { get; set; }
        

        public MainViewModel()
        {
            Items = new ObservableCollection<Item>();
            RemoveCommand = new DelegateCommand(RemoveCommandAction);
            InputCommand = new DelegateCommand(InputCommandAction);
        }

        private void InputCommandAction()
        {
            if(InputText != null)
                Items.Add(new Item(_itemIndex++, InputText));
        }

        private void RemoveCommandAction()
        {
            if(SelectedItem != null)
                Items.Remove(SelectedItem);
        }
    }
}
